# Super Racing MD

Jogo de Mega Drive gerado pelo **Mega Drive Racing Game Maker**.

## Como compilar

Este projeto usa **GitHub Actions** para compilar automaticamente.

### Opção 1: GitHub (Recomendado)
1. Crie um repositório no GitHub
2. Faça push deste projeto
3. Vá em **Actions** → o workflow compila automaticamente
4. Baixe a ROM em **Actions → megadrive-rom → rom.bin**

### Opção 2: Local (SGDK)
```bash
export GDK=/caminho/para/SGDK
make -f $GDK/makefile.gen
```

## Estrutura

```
.
├── src/
│   ├── main.c         # Lógica principal
│   ├── config.h       # Configurações
│   ├── track.c        # Definição da pista
│   └── track.h        # Header da pista
├── res/
│   ├── resources.res  # Lista de recursos
│   └── sprites/
│       └── player.png # Sprite do carro
└── .github/
    └── workflows/
        └── build.yml  # CI/CD
```

## Controles
- **A**: Acelerar
- **B**: Frear
- **Esquerda/Direita**: Virar

## Configurações
- Velocidade máxima: 200 km/h
- Voltas: 3
- Segmentos da pista: 20

---
Gerado em 21/08/2026, 23:02:41
