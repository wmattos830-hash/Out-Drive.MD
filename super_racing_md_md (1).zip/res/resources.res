/*
 * Recursos do jogo - SGDK Resource Compiler
 */

BITMAP player_car "sprites/player.png" NONE
PALETTE player_car_pal "sprites/player.png" 0
