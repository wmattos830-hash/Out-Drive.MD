#ifndef CONFIG_H
#define CONFIG_H

/*
 * Configurações do jogo - geradas automaticamente
 */

#define GAME_TITLE "Super Racing MD"
#define MAX_SPEED 200
#define ACCEL_RATE 0.5
#define BRAKE_RATE 0.8
#define TURN_RATE 0.3
#define TOTAL_LAPS 3
#define TRACK_LENGTH 2000
#define TRACK_SEGMENTS 20

#endif /* CONFIG_H */
