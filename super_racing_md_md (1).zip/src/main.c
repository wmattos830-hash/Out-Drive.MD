/*
 * Super Racing MD
 * Gerado por Mega Drive Racing Game Maker
 * Template: Corrida Pseudo-3D
 */

#include <genesis.h>
#include "config.h"
#include "track.h"
#include "resources.h"

// Estado do jogo
typedef struct {
    fix32 position;
    fix32 speed;
    fix32 playerX;
    u16 currentLap;
    bool gameOver;
} GameState;

static GameState gameState;

void initGame(void) {
    // Inicializa vídeo
    VDP_setScreenWidth320();
    VDP_setPaletteColor(PAL0, 0, RGB24_TO_VDPCOLOR(0x000000));
    
    // Carrega paleta do player
    PAL_setPalette(PAL0, player_car_pal.data, CPU);
    
    // Limpa planos
    VDP_clearPlane(BG_A, TRUE);
    VDP_clearPlane(BG_B, TRUE);
    
    // Mensagem inicial
    VDP_drawText("SUPER RACING MD", 8, 2);
    VDP_drawText("USE A: ACELERAR  B: FREAR", 3, 20);
    VDP_drawText("ESQ/DIR: VIRAR", 8, 22);
    
    // Inicializa estado
    gameState.position = FIX32(0);
    gameState.speed = FIX32(0);
    gameState.playerX = FIX32(0);
    gameState.currentLap = 1;
    gameState.gameOver = FALSE;
}

void handleInput(void) {
    u16 joy = JOY_readJoypad(JOY_1);
    
    // Acelerar
    if (joy & BUTTON_A) {
        gameState.speed = fix32Add(gameState.speed, FIX32(0.5));
        if (fix32ToInt(gameState.speed) > 200) {
            gameState.speed = FIX32(200);
        }
    }
    
    // Frear
    if (joy & BUTTON_B) {
        gameState.speed = fix32Sub(gameState.speed, FIX32(0.8));
        if (fix32ToInt(gameState.speed) < 0) {
            gameState.speed = FIX32(0);
        }
    }
    
    // Virar
    if (joy & BUTTON_LEFT) {
        gameState.playerX = fix32Sub(gameState.playerX, FIX32(0.3));
    }
    if (joy & BUTTON_RIGHT) {
        gameState.playerX = fix32Add(gameState.playerX, FIX32(0.3));
    }
    
    // Limites da pista
    if (fix32ToInt(gameState.playerX) < -100) gameState.playerX = FIX32(-100);
    if (fix32ToInt(gameState.playerX) > 100) gameState.playerX = FIX32(100);
}

void updateGame(void) {
    if (gameState.gameOver) return;
    
    // Atualiza posição
    gameState.position = fix32Add(gameState.position, gameState.speed);
    
    // Verifica volta completa
    if (fix32ToInt(gameState.position) >= 2000) {
        gameState.position = FIX32(0);
        gameState.currentLap++;
        
        if (gameState.currentLap > 3) {
            gameState.gameOver = TRUE;
            VDP_clearPlane(BG_A, TRUE);
            VDP_drawText("CORRIDA FINALIZADA!", 7, 10);
            VDP_drawText("PARABENS!", 11, 14);
        }
    }
}

void renderHUD(void) {
    char buffer[32];
    
    sprintf(buffer, "VOLTA %d/3", gameState.currentLap);
    VDP_drawText(buffer, 2, 2);
    
    sprintf(buffer, "VEL:%03d", fix32ToInt(gameState.speed));
    VDP_drawText(buffer, 30, 2);
}

int main(bool hardReset) {
    initGame();
    
    while(1) {
        handleInput();
        updateGame();
        renderHUD();
        
        SYS_doVBlankProcess();
    }
    
    return 0;
}
