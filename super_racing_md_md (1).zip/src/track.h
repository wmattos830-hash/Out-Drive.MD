#ifndef TRACK_H
#define TRACK_H

#include <genesis.h>
#include "config.h"

typedef struct {
    s16 curve;
    s16 hill;
    u16 length;
} TrackSegment;

extern const TrackSegment track_segments[TRACK_SEGMENTS];

#endif /* TRACK_H */
